export const DOMAIN = "https://reddium.vercel.app";
export const REDIRECT_URI = "https://reddium.vercel.app/login";
export const CLIENT_ID = "DT8MZ0k_rAtJ8w";

// export const REDIRECT_URI = "http://localhost:3000/login";
// export const CLIENT_ID = "RCOnAetgJAnYxQ";

export const CHILDREN_CONTENT = "\n\n\n\n\n\n\n\n\n&lt;div class=\"\n  \n  \n  thing id-t1_getvcwk\n  noncollapsed \n \n  \n  &amp;#32;\n comment  \"\n      id=\"thing_t1_getvcwk\"\n     onclick=\"click_thing(this)\"\n    \n  \n  \n      \n      data-fullname=\"t1_getvcwk\"\n      data-type=\"comment\"\n\n    data-gildings=\"0\"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n    data-subreddit=\"AskReddit\"\n    data-subreddit-prefixed=\"r/AskReddit\"\n    data-subreddit-fullname=\"t5_2qh1i\"\n    data-subreddit-type=\"public\"\n\n\n\n    data-author=\"Commentingunreddit\"\n    data-author-fullname=\"t2_4v9kxdwk\"\n\n\n    data-replies=\"0\"\n\n\n      data-permalink=\"/r/AskReddit/comments/k7pmbf/exprisoners_of_reddit_what_was_the_worst_thing/getvcwk/\"\n\n&gt;\n  &lt;p class=\"parent\"&gt;\n    \n  \n\n    &lt;a name=\"getvcwk\"&gt;&lt;/a&gt;\n\n  &lt;/p&gt;\n  \n\n  \n  \n\n  \n  &lt;div class=\"midcol unvoted\"\n       &gt;\n    \n\n  &lt;div \nclass=\"arrow up login-required access-required\"\n\n    data-event-action=\"upvote\"\n       role=\"button\"\n       aria-label=\"upvote\"\n       tabindex=\"0\"\n    &gt;\n  &lt;/div&gt;\n\n    \n\n  &lt;div \nclass=\"arrow down login-required access-required\"\n\n    data-event-action=\"downvote\"\n       role=\"button\"\n       aria-label=\"downvote\"\n       tabindex=\"0\"\n    &gt;\n  &lt;/div&gt;\n\n  &lt;/div&gt;\n\n\n\n  &lt;div class=\"entry unvoted\"&gt;\n    \n\n\n&lt;p class=\"tagline\"&gt;\n  \n  \n\n  &lt;a href=\"javascript:void(0)\" class=\"expand\" onclick=\"return togglecomment(this)\"&gt;\n    [–]\n  &lt;/a&gt;\n\n    \n\n\n\n\n\n\n\n    \n    \n  \n\n  \n&lt;a \n      href=\"https://www.reddit.com/user/Commentingunreddit\"       class=\"author may-blank id-t2_4v9kxdwk\" &gt;Commentingunreddit&lt;/a&gt;\n\n\n      \n\n    \n&lt;span class=\"userattrs\"&gt;\n&lt;/span&gt;\n\n\n\n\n    &amp;#32;\n\n\n\n    \n  \n    &lt;span class=\"score dislikes\" title=\"19\"&gt;\n      19 points\n    &lt;/span&gt;\n    &lt;span class=\"score unvoted\" title=\"20\"&gt;\n      20 points\n    &lt;/span&gt;\n    &lt;span class=\"score likes\" title=\"21\"&gt;\n      21 points\n    &lt;/span&gt;\n&amp;#32;\n\n  \n  \n  \n  &lt;time title=\"Sun Dec  6 13:55:17 2020 UTC\" datetime=\"2020-12-06T13:55:17+00:00\" class=\"live-timestamp\"&gt;\n    2 hours ago\n  &lt;/time&gt;\n\n\n  \n\n\n    \n  &lt;span\n    class=\"awardings-bar\"\n      data-subredditpath=\"/r/AskReddit/\"\n  &gt;\n  &lt;/span&gt;\n\n\n  \n\n\n\n\n  &amp;nbsp;\n  &lt;a href=\"javascript:void(0)\" class=\"numchildren\" onclick=\"return togglecomment(this)\"&gt;\n    (0 children)\n  &lt;/a&gt;\n\n  \n\n\n\n&lt;/p&gt;\n\n\n  \n  \n\n\n\n\n\n\n\n\n\n  &lt;form action=\"#\" class=\"usertext warn-on-unload\"\n        onsubmit=\"return post_form(this, 'editusertext')\"\n        \n        id=\"form-t1_getvcwk6aa\"&gt;\n\n  &lt;input type=\"hidden\" name=\"thing_id\" value=\"t1_getvcwk\"/&gt;\n\n\n    &lt;div class=\"usertext-body may-blank-within md-container \"\n      &gt;\n      \n  &lt;!-- SC_OFF --&gt;&lt;div class=\"md\"&gt;&lt;p&gt;Ive never been to prison but my cousin did and He came back out all sorts of messed up, \nHe was arrested for drugs.&lt;/p&gt;\n\n&lt;p&gt;according to him he spent the majority of his time in solitary confinement. For his safety.\nHe said that his first couple of months there were ok, as far as prison goes.&lt;/p&gt;\n\n&lt;p&gt;But that one day, for whatever reason some guy who had been kept separate from the general population was accidentally put with the rest of the prisoners, unsupervised and that a few prisoners grabbed the guy and that they stomped on his elbows and legs to break them before they sodomized him with some shivs. &lt;/p&gt;\n\n&lt;p&gt;My cousin said it that those guys did it all in a instant and that they threatened him if he snitched, my cousin was later interviewed by some of the guards before they took the guys who did this and so some thought that he had snitched.&lt;/p&gt;\n\n&lt;p&gt;He says that he didn&amp;#39;t, but that didn&amp;#39;t matter because the guards had put him in solitary for &amp;quot;safety&amp;quot; and was eventually kept there for months longer, because he wouldn&amp;#39;t snitch so they tried to accuse him of being an accomplice.&lt;/p&gt;\n&lt;/div&gt;&lt;!-- SC_ON --&gt;\n\n    &lt;/div&gt;\n\n\n  &lt;/form&gt;\n\n\n\n\n&lt;ul class=\"flat-list buttons\"&gt;\n  \n  \n    &lt;li class=\"first\"&gt;\n      \n  \n  \n  \n\n  \n&lt;a \n      href=\"https://www.reddit.com/r/AskReddit/comments/k7pmbf/exprisoners_of_reddit_what_was_the_worst_thing/getvcwk/\"       \ndata-event-action=\"permalink\"\n\n      class=\"bylink\"       rel=\"nofollow\" &gt;permalink&lt;/a&gt;\n\n\n\n    &lt;/li&gt;\n\n      &lt;li class=\"comment-save-button save-button login-required\"&gt;\n        &lt;a href=\"javascript:void(0)\"&gt;save&lt;/a&gt;\n      &lt;/li&gt;\n\n\n\n\n    \n\n    &lt;li class=\"report-button login-required\"&gt;\n      &lt;a href=\"javascript:void(0)\" class=\"reportbtn access-required\"\n        data-event-action=\"report\"&gt;\n          report\n      &lt;/a&gt;\n    &lt;/li&gt;\n\n    \n\n    \n\n    \n    &lt;li class=\"give-gold-button\"&gt;\n    &lt;a href=\"/gold?goldtype=gift&amp;months=1&amp;thing=t1_getvcwk\"\n        title=\"give an award in appreciation of this post.\"\n        class=\"give-gold login-required access-required gold-give-gold\"\n        data-event-action=\"gild\"\n        data-community-awards-enabled=True\n        rel=\"nofollow\"\n        &gt;give award&lt;/a&gt;\n    &lt;/li&gt;\n\n    \n\n    \n\n\n    \n\n\n        &lt;li class=\"reply-button login-required\"&gt;\n          \n &lt;a class=\"access-required\" href=\"javascript:void(0)\" \n      data-event-action=\"comment\"\n    onclick=\"return reply(this)\"&gt;reply&lt;/a&gt;\n\n        &lt;/li&gt;\n\n    \n\n\n\n\n\n\n  \n\n\n&lt;/ul&gt;\n&lt;div class=\"reportform report-t1_getvcwk\"&gt;&lt;/div&gt;\n\n  &lt;/div&gt;\n  \n  &lt;div class=\"child\"&gt;\n    \n  &lt;/div&gt;\n\n  &lt;div class=\"clearleft\"&gt;&lt;/div&gt;\n&lt;/div&gt;\n&lt;div class=\"clearleft\"&gt;&lt;/div&gt;\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"

export const TITLE_MAX = 100;
export const DESC_MAX = 200;
export const BLURB_MAX = 600;

export const SPECIAL_SUBREDDITS = ["all", "popular"];

export const SORT_TYPE = "sort_type";
export const SORT_PARAM = "sort";
export const GEO_FILTER = "geo_filter";
export const TIME_FILTER = "t";

export const TIME_PARAM_VALUES = [
  "hour",
  "day",
  "week",
  "month",
  "year",
  "all"
];
export const SORT_TYPES_COMMENT = [
  "confidence",
  "top",
  "new",
  "controversial",
  "old",
  "qa"
];
export const COMMENT_PARAM_KEY = ["sort"];
export const COMMENT_PARAM_DEFAULT = ["confidence"];
export const COMMENT_PARAM_VALUES = [SORT_TYPES_COMMENT];
export const SORT_TYPES_SEARCH = ["relevance", "top", "hot", "new", "comments"];
export const SEARCH_PARAM_KEY = ["sort", "t"];
export const SEARCH_PARAM_DEFAULT = ["relevance", "all"];
export const SEARCH_PARAM_VALUES = [SORT_TYPES_SEARCH, TIME_PARAM_VALUES];
export const SORT_TYPES = ["top", "hot", "new", "rising"];
export const POPULAR_PARAM_KEY = ["sort_type", "t"];
export const POPULAR_PARAM_DEFAULT = ["hot", "day"];
export const POPULAR_PARAM_VALUES = [SORT_TYPES, TIME_PARAM_VALUES];

export const LOADING_POST_LIST = { posts: new Array(15).fill({}), after: "" };

export const PLACEHOLDER_IMAGES = [
  "amanda-frank-e4ING8JYKgI-unsplash.jpg",
  "dylan-gillis-KdeqA3aTnBY-unsplash.jpg",
  "ilya-pavlov-OqtafYT5kTw-unsplash.jpg",
  "izuddin-helmi-adnan-vTveTqbaTNM-unsplash.jpg",
  "jeremy-bishop-B2Q7UC6QGLE-unsplash.jpg",
  "marek-piwnicki-6xNqGogcQ5Q-unsplash.jpg",
  "melnychuk-nataliya-OYT2j0LnImg-unsplash.jpg",
  "nubelson-fernandes-CO6r5hbt1jg-unsplash.jpg",
  "olga-isakova-w-GieCARg44-unsplash.jpg",
  "roman-bozhko-PypjzKTUqLo-unsplash.jpg",
  "stephen-walker-Aemzb5kqs2E-unsplash.jpg",
  "stil-flRm0z3MEoA-unsplash.jpg",
  "thomas-de-luze-4lTtaunPhrk-unsplash.jpg",
  "vista-wei-Zp4uEoNmhbQ-unsplash.jpg",
  "vlad-hilitanu-oKc7vCb4SS4-unsplash.jpg",
  "you-x-ventures-Oalh2MojUuk-unsplash.jpg"
];
