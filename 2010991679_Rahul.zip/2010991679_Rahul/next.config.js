module.exports = {
  images: {
    unoptimized: true,
    domains: ["a.thumbs.redditmedia.com"],
  },
};
